#include "Spline.h"

Spline::Spline(glm::vec3 start, glm::vec3 control, glm::vec3 end, float duration)
{
    t = 0;
    order = ORDER2;
    done = false;
    this->start = start;
    this->end = end;
    this->control1 = control;
    this->duration = duration;
}

Spline::Spline(glm::vec3 start, glm::vec3 control1, glm::vec3 control2, glm::vec3 end, float duration) 
{
    t = 0;
    order = ORDER3;
    done = false;
    this->start = start;
    this->end = end;
    this->control1 = control1;
    this->control2 = control2;
    this->duration = duration;
}

Spline::~Spline()
{
}

void Spline::update(float deltaTime)
{
    //

    // scale the deltatime by the duration
    // so that it works with the parameterized 
    // Bezier functions, which expext 0<=t<=1
    t += deltaTime / duration;
    // don't overshoot 1
    if(t > 1)
    {
        t = 1;
        done = true;
    }
}

void Spline::updateWithPolling(float deltaTime, Spline newPos) {
    //preserve things like the current t and duration, but allow updates to a spline's curve-points mid-animation
    this->start = newPos.start;
    this->control1 = newPos.control1;
    this->control2 = newPos.control2;
    this->end = newPos.end;
    this->update(deltaTime);
}

bool Spline::isDone()
{
    return done;
}

void Spline::reset()
{
    t = 0;
    done = false;
}

glm::vec3 Spline::getPosition()
{
    if(order == ORDER2)
        return Bezier::quadBez(Bezier::lErp, start, end, control1, t);
    else
        return Bezier::cubeBez(Bezier::lErp, start, end, control1, control2, t);
}